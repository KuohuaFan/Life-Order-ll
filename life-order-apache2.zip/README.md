# Life & Order ll™ — 生活智慧代理 / Life Intelligence Agent

以共同生活、協調修復與安全底線為核心的會員制生活智慧代理。
單一自包含 `index.html`,無建置流程,可直接部署於 GitHub Pages。

A membership-style life intelligence agent centered on shared living,
mediated repair, and safety baselines. Single self-contained `index.html`,
no build toolchain, deployable directly to GitHub Pages.

## 功能 Features

- **對話代理**:「共同事實 → 彼此需要 → 下一步」三段協調架構,內嵌六大生活領域(食衣住行育樂)規範分類
- **探索與紀錄**:六大領域手風琴與情境建議問題
- **VIP 翻譯**:AI 回覆一鍵翻譯 18 種語言
- **語音**:Web Speech API 逐字稿輸入(zh-TW)與回覆朗讀
- **影像**:拍照附件送交 AI 影像分析;影音紀錄事件帳
- **法律資料庫(只讀)**:法規/lawTW 與裁判/reportBase 雙 Solr 核心檢索,端點可於管理後台設定;未設定時提供 [裁判家](https://www.lawplus.com.tw/) 與 [評律網](https://www.pingluweb.com.tw/) 外部檢索連結
- **資料主權**:所有紀錄僅存於瀏覽器本機 localStorage;可調保存期限、匯出 JSON、一鍵刪除

## 部署 Deployment

1. 建立 GitHub repository,上傳本專案檔案
2. Settings → Pages → Source 選 `main` branch(root)
3. 完成。網址為 `https://<username>.github.io/<repo>/`

### AI 對話設定

外部部署時,於「管理後台 → INTEGRATIONS」填入您自己的 Anthropic API Key。
**Key 僅儲存於使用者本機瀏覽器,不會寫入原始碼、不會上傳至任何伺服器**;
每位使用者需自行填入自己的 Key。請勿將 Key 寫入原始碼後推送至公開 repo。

### Solr 檢索設定

於管理後台填入您的 Solr select 端點,例如:

```
https://your-solr-host/solr/lawTW/select
https://your-solr-host/solr/reportBase/select
```

端點需允許來自您網域的 CORS 請求,並建議僅開放唯讀查詢。

## 隱私與免責 Privacy & Disclaimer

- 本工具為協調與紀錄用途,**非法律意見**;涉及權利義務請諮詢執業律師。
- 影音錄製請符合所在地法規並尊重他人隱私。
- 對話內容經由 Anthropic API 處理;其餘資料不離開使用者裝置。

## 授權 License

程式碼以 [Apache License 2.0](LICENSE) 釋出:可自由使用、修改、散布(含商業用途),
並附帶明示專利授權與貢獻條款;惟依授權第 6 條,**不授予任何商標使用權**
(詳見 [NOTICE](NOTICE))。散布修改版時請保留 LICENSE 與 NOTICE 檔案。

Code released under the [Apache License 2.0](LICENSE) — free to use, modify,
and redistribute (including commercially), with an express patent grant and
contribution terms. No trademark rights are granted (License §6; see
[NOTICE](NOTICE)). Retain the LICENSE and NOTICE files in redistributions.

### 意見與回饋 Feedback

歡迎透過 GitHub Issues 回報問題或提出建議;
提交的貢獻依 Apache 2.0 第 5 條以相同授權條款納入本專案。

Feedback via GitHub Issues is welcome. Contributions are accepted under
the terms of the Apache License 2.0, Section 5.

## 姊妹專案 Sister Projects

- [Huayan Sutra 華嚴經](https://kuohuafan.github.io/Huayan-Sutra)
- [Lotus Sutra 法華經](https://kuohuafan.github.io/Lotus-Sutra/)
- Yijing-Classic 周易
